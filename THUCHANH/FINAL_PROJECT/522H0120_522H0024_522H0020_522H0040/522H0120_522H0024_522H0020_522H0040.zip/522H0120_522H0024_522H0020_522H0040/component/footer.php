<footer>
        <p>&copy; 2024 Flower Shop Management</p>
</footer>