<script>
  $(document).ready(function() {
    $('#p_use').click(function() {
      uni_modal("Privacy Policy", "policy.php", "mid-large")
    })
    window.viewer_modal = function($src = '') {
      start_loader()
      var t = $src.split('.')
      t = t[1]
      if (t == 'mp4') {
        var view = $("<video src='" + $src + "' controls autoplay></video>")
      } else {
        var view = $("<img src='" + $src + "' />")
      }
      $('#viewer_modal .modal-content video,#viewer_modal .modal-content img').remove()
      $('#viewer_modal .modal-content').append(view)
      $('#viewer_modal').modal({
        show: true,
        backdrop: 'static',
        keyboard: false,
        focus: true
      })
      end_loader()

    }
    window.uni_modal = function($title = '', $url = '', $size = "") {
      start_loader()
      $.ajax({
        url: $url,
        error: err => {
          console.log()
          alert("An error occured")
        },
        success: function(resp) {
          if (resp) {
            $('#uni_modal .modal-title').html($title)
            $('#uni_modal .modal-body').html(resp)
            if ($size != '') {
              $('#uni_modal .modal-dialog').addClass($size + '  modal-dialog-centered')
            } else {
              $('#uni_modal .modal-dialog').removeAttr("class").addClass("modal-dialog modal-md modal-dialog-centered")
            }
            $('#uni_modal').modal({
              show: true,
              backdrop: 'static',
              keyboard: false,
              focus: true
            })
            end_loader()
          }
        }
      })
    }
    window._conf = function($msg = '', $func = '', $params = []) {
      $('#confirm_modal #confirm').attr('onclick', $func + "(" + $params.join(',') + ")")
      $('#confirm_modal .modal-body').html($msg)
      $('#confirm_modal').modal('show')
    }
  })
</script>
<link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
<style>
  .top-footer,
  .bottom-footer {
    border-top: 1px solid rgb(204 204 204 / 40%);
    position: relative;
  }

  .footer-logo {
    margin-bottom: 30px;
  }

  .footer-info .social-icon {
    margin-top: 20px;
  }

  .footer-flex-box {
    display: flex;
    margin: 0 -10px;
  }

  .footer-flex-box>div {
    flex: 1;
    padding: 0 10px;
  }

  .footer-flex-box .h3-title {
    text-transform: capitalize;
    margin-bottom: 23px;
  }

  .footer-menu ul li a {
    color: #0d0d25;
    transition: 0.3s;
    text-transform: capitalize;
  }

  .footer-menu ul li a:hover,
  .footer-menu ul li .footer-active-menu {
    color: #ff8243;
  }

  .footer-menu ul li {
    margin-bottom: 8px;
  }

  .footer-table-info ul li {
    margin-bottom: 10px;
    text-transform: capitalize;
  }

  .uil-clocl {
    font-size: 17px;
  }

  .copyright-text {
    padding: 20px 0;
  }

  .copyright-text p {
    margin: 0;
  }

  footer div {
    color: lightgrey;
  }

  footer a {
    color: orange;
  }

</style>
<!-- Footer-->
<footer class="py-4 " style="background-color:brown; ">
  <div class="top-footer section">
    <div class="sec-wp">
      <div class="container">
        <div class="row">
          <div class="col-lg-4">
            <div class="footer-info">
              <div class="footer-logo">
                <a href="home.php">
                  <img style="border-radius: 30px;" src="<?php echo validate_image($_settings->info('logo')) ?>" width="120" height="80" class="d-inline-block align-top" alt="" loading="lazy"> </a>
              </div>
              <p>Every girl loves surprises, especially if it's something romantic in honor of her birthday.
              </p>
              <p>Even a small gift such as flowers, together with the right words, can make a lasting impression and make her feel like she’s on top of the world.</p>
              <p>So, don t be afraid to be too tender</p>
              <div class="social-icon">
                <ul>
                  <li>
                    <a href="#">
                      <i class="uil uil-facebook-f"></i>
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <i class="uil uil-instagram"></i>
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <i class="uil uil-github-alt"></i>
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <i class="uil uil-youtube"></i>
                    </a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div class="col-lg-8">
            <div class="footer-flex-box">
              <div class="footer-table-info">
                <h3 class="h3-title">open hours</h3>
                <ul>
                  <li><i class="uil uil-clock"></i> Mon-Thurs : 9am - 22pm</li>
                  <li><i class="uil uil-clock"></i> Fri-Sun : 11am - 22pm</li>
                </ul>
              </div>
              <div class="footer-menu food-nav-menu">
                <h3 class="h3-title">Links</h3>
                <ul class="column-2">
                  <li>
                    <a href="#home" class="footer-active-menu">Home</a>
                  </li>
                  <li><a style="color:lightgrey" href="about.html">About</a></li>
                  <li><a style="color:lightgrey" href="#menu">Menu</a></li>
                  <li><a style="color:lightgrey" href="#gallery">Gallery</a></li>
                  <li><a style="color:lightgrey" href="#blog">Blog</a></li>
                  <li><a style="color:lightgrey" href="#contact">Contact</a></li>
                </ul>
              </div>
              <div class="footer-menu">
                <h3 class="h3-title">Company</h3>
                <ul>
                  <li><a style="color:lightgrey" href="#">Terms & Conditions</a></li>
                  <li><a style="color:lightgrey" href="#">Privacy Policy</a></li>
                  <li><a style="color:lightgrey" href="#">Cookie Policy</a></li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="container">
    <p class="m-0 text-center text-lightgrey">Copyright &copy; <?php echo $_settings->info('short_name') ?> 2024</p>
    <p class="m-0 text-center text-lightgrey">Developed By: <a href="mailto:oretnom23@gmail.com">Group 1 - PTTKYC</a></p>
  </div>
</footer>


<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
  $.widget.bridge('uibutton', $.ui.button)
</script>
<!-- Bootstrap 4 -->
<script src="<?php echo base_url ?>plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- ChartJS -->
<script src="<?php echo base_url ?>plugins/chart.js/Chart.min.js"></script>
<!-- Sparkline -->
<script src="<?php echo base_url ?>plugins/sparklines/sparkline.js"></script>
<!-- Select2 -->
<script src="<?php echo base_url ?>plugins/select2/js/select2.full.min.js"></script>
<!-- JQVMap -->
<script src="<?php echo base_url ?>plugins/jqvmap/jquery.vmap.min.js"></script>
<script src="<?php echo base_url ?>plugins/jqvmap/maps/jquery.vmap.usa.js"></script>
<!-- jQuery Knob Chart -->
<script src="<?php echo base_url ?>plugins/jquery-knob/jquery.knob.min.js"></script>
<!-- daterangepicker -->
<script src="<?php echo base_url ?>plugins/moment/moment.min.js"></script>
<script src="<?php echo base_url ?>plugins/daterangepicker/daterangepicker.js"></script>
<!-- Tempusdominus Bootstrap 4 -->
<script src="<?php echo base_url ?>plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
<!-- Summernote -->
<script src="<?php echo base_url ?>plugins/summernote/summernote-bs4.min.js"></script>
<script src="<?php echo base_url ?>plugins/datatables/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url ?>plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="<?php echo base_url ?>plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="<?php echo base_url ?>plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
<!-- overlayScrollbars -->
<!-- <script src="<?php echo base_url ?>plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script> -->
<!-- AdminLTE App -->
<script src="<?php echo base_url ?>dist/js/adminlte.js"></script>
<div class="daterangepicker ltr show-ranges opensright">
  <div class="ranges">
    <ul>
      <li data-range-key="Today">Today</li>
      <li data-range-key="Yesterday">Yesterday</li>
      <li data-range-key="Last 7 Days">Last 7 Days</li>
      <li data-range-key="Last 30 Days">Last 30 Days</li>
      <li data-range-key="This Month">This Month</li>
      <li data-range-key="Last Month">Last Month</li>
      <li data-range-key="Custom Range">Custom Range</li>
    </ul>
  </div>
  <div class="drp-calendar left">
    <div class="calendar-table"></div>
    <div class="calendar-time" style="display: none;"></div>
  </div>
  <div class="drp-calendar right">
    <div class="calendar-table"></div>
    <div class="calendar-time" style="display: none;"></div>
  </div>
  <div class="drp-buttons"><span class="drp-selected"></span><button class="cancelBtn btn btn-sm btn-default" type="button">Cancel</button><button class="applyBtn btn btn-sm btn-primary" disabled="disabled" type="button">Apply</button> </div>
</div>
<div class="jqvmap-label" style="display: none; left: 1093.83px; top: 394.361px;">Idaho</div>