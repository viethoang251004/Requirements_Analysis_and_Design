-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1
-- Thời gian đã tạo: Th5 15, 2024 lúc 07:10 AM
-- Phiên bản máy phục vụ: 10.4.32-MariaDB
-- Phiên bản PHP: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `flshop_db`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `brands`
--

CREATE TABLE `brands` (
  `id` int(30) NOT NULL,
  `name` varchar(250) NOT NULL,
  `description` text DEFAULT NULL,
  `image_path` text DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `delete_flag` tinyint(1) NOT NULL DEFAULT 0,
  `date_created` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `brands`
--

INSERT INTO `brands` (`id`, `name`, `description`, `image_path`, `status`, `delete_flag`, `date_created`) VALUES
(1, 'Roses', '', NULL, 1, 0, '2024-05-14 19:45:22'),
(2, 'Tulips', '', NULL, 1, 0, '2024-05-14 19:45:37'),
(3, 'Lilies', '', NULL, 1, 0, '2024-05-14 19:45:46'),
(4, 'Sunflowers', '', NULL, 1, 0, '2024-05-14 19:45:58'),
(5, 'Orchids', '', NULL, 1, 0, '2024-05-14 19:46:31'),
(6, 'Irises', '', NULL, 1, 0, '2024-05-14 19:47:03');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `cart`
--

CREATE TABLE `cart` (
  `id` int(30) NOT NULL,
  `client_id` int(30) NOT NULL,
  `inventory_id` int(30) NOT NULL,
  `price` double NOT NULL,
  `quantity` int(30) NOT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `categories`
--

CREATE TABLE `categories` (
  `id` int(30) NOT NULL,
  `category` varchar(250) NOT NULL,
  `description` text DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `delete_flag` tinyint(1) NOT NULL DEFAULT 0,
  `date_created` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `categories`
--

INSERT INTO `categories` (`id`, `category`, `description`, `status`, `delete_flag`, `date_created`) VALUES
(1, 'Birthday', 'A birthday is a special annual celebration marking the anniversary of a person\'s birth. It is a time for joy, reflection, and gratitude, often shared with family and friends. Traditions vary widely but commonly include gift-giving, cake, and parties. Many people use this day to make wishes, often symbolized by blowing out candles on a birthday cake. Birthdays can also be a moment to look back on the past year, set goals for the future, and appreciate the journey of life. Each birthday serves as a personal milestone, highlighting growth, achievements, and the passage of time.', 1, 0, '2024-05-14 19:48:13'),
(2, 'Gifts', 'Gifts are thoughtful items given to celebrate special occasions, express love, or show appreciation. They come in various forms, from personalized keepsakes to practical gadgets, tailored to the recipient\'s preferences and interests. Common gifts include jewelry, books, electronics, clothing, and handcrafted items. Experiences, such as concert tickets or spa vouchers, also make memorable gifts. The act of giving a gift involves careful consideration of the recipient\'s tastes, adding a personal touch that enhances the gesture. Wrapped in decorative paper or presented in elegant boxes, gifts bring joy and strengthen relationships, making moments special and memorable.', 1, 0, '2024-05-14 19:48:32'),
(3, 'Occasions', 'Occasions are significant events or moments that hold cultural, social, or personal importance, often marked by celebration or ceremony. They encompass a wide range of events, from birthdays and weddings to holidays and graduations. Occasions provide opportunities for people to come together, share joy, and create lasting memories. They serve as milestones in life, signaling transitions, achievements, and new beginnings. Whether it\'s a formal gathering or an intimate affair, occasions are infused with traditions, rituals, and customs that vary across cultures and communities. They offer moments of reflection, connection, and appreciation, enriching the tapestry of human experience.', 1, 0, '2024-05-14 19:49:43'),
(4, 'Arrangements', 'Arrangements refer to the careful organization or positioning of elements to create a harmonious composition or plan. In various contexts, arrangements can involve the placement of objects, the coordination of schedules, or the negotiation of agreements. For example, in the context of floral design, arrangements involve the artistic combination of flowers, foliage, and other materials to create visually appealing displays. In music, arrangements refer to adaptations or compositions of a piece of music for a specific instrumentation or performance style. In business, arrangements can pertain to agreements, contracts, or plans made between parties to facilitate a transaction or collaboration. Overall, arrangements play a crucial role in bringing order, beauty, and efficiency to different aspects of life and work.', 1, 0, '2024-05-14 19:50:12'),
(5, 'Spring', 'Spring is a season of renewal, vitality, and growth, typically occurring between the end of winter and the beginning of summer in the Northern Hemisphere. It is characterized by longer days, warmer temperatures, and the awakening of nature from its winter slumber. During spring, flowers bloom, trees sprout new leaves, and animals emerge from hibernation. The landscape is transformed into a colorful tapestry of blossoms and greenery. Spring is also associated with themes of rejuvenation, hope, and new beginnings, making it a time for cleaning, organizing, and starting fresh. Many cultures celebrate spring festivals, marking the end of the cold season and the onset of warmer, more fertile conditions for agriculture and outdoor activities.', 1, 0, '2024-05-14 19:51:28');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `clients`
--

CREATE TABLE `clients` (
  `id` int(30) NOT NULL,
  `firstname` varchar(250) NOT NULL,
  `lastname` varchar(250) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `contact` varchar(15) NOT NULL,
  `email` varchar(250) NOT NULL,
  `password` text NOT NULL,
  `default_delivery_address` text NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `delete_flag` tinyint(1) NOT NULL DEFAULT 0,
  `date_created` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `clients`
--

INSERT INTO `clients` (`id`, `firstname`, `lastname`, `gender`, `contact`, `email`, `password`, `default_delivery_address`, `status`, `delete_flag`, `date_created`) VALUES
(2, 'Nguyen Viet', 'Hoang', 'Male', '09123456789', 'sam23@sample.com', '45bff2a14658fc9b21c6e5e9bf75186b', 'Sample Address', 1, 0, '2022-02-17 14:24:00'),
(3, 'Hoàng', 'Minh', 'Male', '0393699395', 'vamila2710@gmail.com', '4297f44b13955235245b2497399d7a93', 'Gò Vấp', 1, 0, '2024-05-14 18:21:30');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `inventory`
--

CREATE TABLE `inventory` (
  `id` int(30) NOT NULL,
  `variant` text NOT NULL,
  `product_id` int(30) NOT NULL,
  `quantity` double NOT NULL,
  `price` float NOT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `inventory`
--

INSERT INTO `inventory` (`id`, `variant`, `product_id`, `quantity`, `price`, `date_created`, `date_updated`) VALUES
(35, 'Standard', 2, 123, 222, '2024-05-14 21:15:30', NULL),
(36, 'Standard', 7, 32, 120, '2024-05-14 21:15:39', NULL),
(37, 'Standard', 8, 233, 120, '2024-05-14 21:15:50', NULL),
(38, 'Standard', 14, 222, 111, '2024-05-14 21:15:58', NULL),
(39, 'Standard', 11, 333, 112, '2024-05-14 21:16:07', NULL),
(40, 'Standard', 1, 221, 221, '2024-05-14 21:16:16', '2024-05-14 21:16:23'),
(41, 'Standard', 6, 21, 201, '2024-05-14 21:16:35', NULL),
(42, 'Standard', 15, 221, 235, '2024-05-14 21:16:47', NULL),
(43, 'Standard', 4, 371, 231, '2024-05-14 21:16:56', NULL),
(44, 'Standard', 5, 21, 322, '2024-05-14 21:17:05', NULL),
(45, 'Standard', 12, 332, 111, '2024-05-14 21:17:14', NULL),
(46, 'Standard', 3, 32, 732, '2024-05-14 21:17:27', NULL),
(47, 'Standard', 10, 31, 221, '2024-05-14 21:17:39', NULL),
(48, 'Standard', 13, 11, 222, '2024-05-14 21:17:49', NULL),
(49, 'Standard', 9, 231, 331, '2024-05-14 21:17:57', NULL);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `orders`
--

CREATE TABLE `orders` (
  `id` int(30) NOT NULL,
  `ref_code` varchar(100) NOT NULL,
  `client_id` int(30) NOT NULL,
  `delivery_address` text NOT NULL,
  `payment_method` varchar(100) NOT NULL,
  `order_type` tinyint(1) NOT NULL COMMENT '1= pickup,2= deliver',
  `amount` double NOT NULL,
  `status` tinyint(2) NOT NULL DEFAULT 0 COMMENT '0 = pending,\r\n1= Packed,\r\n2 = Out for Delivery,\r\n3=Delivered,\r\n4=cancelled',
  `paid` tinyint(1) NOT NULL DEFAULT 0,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `orders`
--

INSERT INTO `orders` (`id`, `ref_code`, `client_id`, `delivery_address`, `payment_method`, `order_type`, `amount`, `status`, `paid`, `date_created`, `date_updated`) VALUES
(13, '20240500001', 3, 'Gò Vấp \r\n', 'cod', 0, 777, 2, 0, '2024-05-14 21:40:27', '2024-05-15 12:06:41'),
(14, '20240500002', 3, 'Gò Vấp \r\n', 'cod', 0, 777, 4, 1, '2024-05-14 21:42:50', '2024-05-15 12:06:23'),
(0, '20240500003', 3, 'Gò Vấp', 'cod', 0, 777, 3, 1, '2024-05-14 21:45:28', '2024-05-15 12:06:09');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `order_list`
--

CREATE TABLE `order_list` (
  `id` int(30) NOT NULL,
  `order_id` int(30) NOT NULL,
  `inventory_id` int(30) NOT NULL,
  `quantity` int(30) NOT NULL,
  `price` double NOT NULL,
  `total` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `order_list`
--

INSERT INTO `order_list` (`id`, `order_id`, `inventory_id`, `quantity`, `price`, `total`) VALUES
(0, 0, 10, 1, 221, 221),
(0, 0, 11, 1, 112, 112),
(0, 0, 12, 1, 111, 111),
(0, 0, 13, 1, 222, 222),
(0, 0, 14, 1, 111, 111);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `products`
--

CREATE TABLE `products` (
  `id` int(30) NOT NULL,
  `brand_id` int(30) NOT NULL,
  `category_id` int(30) NOT NULL,
  `name` varchar(250) NOT NULL,
  `specs` text NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `delete_flag` tinyint(1) NOT NULL DEFAULT 0,
  `date_created` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `products`
--

INSERT INTO `products` (`id`, `brand_id`, `category_id`, `name`, `specs`, `status`, `delete_flag`, `date_created`) VALUES
(1, 1, 1, 'Bouquet Hearts', '', 1, 0, '2024-05-14 20:33:58'),
(2, 1, 4, 'Bouquet Clouds', '', 1, 0, '2024-05-14 20:34:22'),
(3, 1, 2, 'Bouquet Pink ', '', 1, 0, '2024-05-14 20:34:40'),
(4, 6, 1, 'Bouquet Lifes', '', 1, 0, '2024-05-14 20:35:02'),
(5, 6, 3, 'Bouquet Lights', '', 1, 0, '2024-05-14 20:35:18'),
(6, 6, 3, 'Bouquet Hopes', '', 1, 0, '2024-05-14 20:35:36'),
(7, 3, 3, 'Bouquet Colors', '', 1, 0, '2024-05-14 20:36:39'),
(8, 3, 5, 'Bouquet Cools', '', 1, 0, '2024-05-14 20:38:19'),
(9, 3, 2, 'Bouquet Sweat', '', 1, 0, '2024-05-14 20:38:43'),
(10, 5, 3, 'Bouquet Powers', '', 1, 0, '2024-05-14 20:39:20'),
(11, 5, 4, 'Bouquet Hat', '', 1, 0, '2024-05-14 20:39:47'),
(12, 5, 3, 'Bouquet March', '', 1, 0, '2024-05-14 20:40:12'),
(13, 4, 2, 'Bouquet Sunrise', '', 1, 0, '2024-05-14 20:40:33'),
(14, 4, 1, 'Bouquet Felix', '', 1, 0, '2024-05-14 20:41:01'),
(15, 2, 3, 'Bouquet Joys', '', 1, 0, '2024-05-14 20:41:27');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `sales`
--

CREATE TABLE `sales` (
  `id` int(30) NOT NULL,
  `order_id` int(30) NOT NULL,
  `total_amount` double NOT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `sales`
--

INSERT INTO `sales` (`id`, `order_id`, `total_amount`, `date_created`) VALUES
(1, 0, 655, '2024-05-05 23:36:38'),
(2, 0, 2703, '2024-05-07 20:38:00'),
(3, 0, 777, '2024-05-14 21:45:28');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `system_info`
--

CREATE TABLE `system_info` (
  `id` int(30) NOT NULL,
  `meta_field` text NOT NULL,
  `meta_value` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `system_info`
--

INSERT INTO `system_info` (`id`, `meta_field`, `meta_value`) VALUES
(1, 'name', 'My Global Flowers'),
(6, 'short_name', 'Flowers'),
(11, 'logo', 'uploads/logo1.webp'),
(13, 'user_avatar', 'uploads/user_avatar.jpg'),
(14, 'cover', 'uploads/cover6.jpg');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `users`
--

CREATE TABLE `users` (
  `id` int(50) NOT NULL,
  `firstname` varchar(250) NOT NULL,
  `lastname` varchar(250) NOT NULL,
  `username` text NOT NULL,
  `password` text NOT NULL,
  `avatar` text DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `type` tinyint(1) NOT NULL DEFAULT 0,
  `date_added` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `users`
--

INSERT INTO `users` (`id`, `firstname`, `lastname`, `username`, `password`, `avatar`, `last_login`, `type`, `date_added`, `date_updated`) VALUES
(1, 'Adminstrator', 'Admin', 'admin', '4297f44b13955235245b2497399d7a93', 'uploads/avatars/1.jpg', NULL, 1, '2021-01-20 14:02:37', '2024-05-14 18:22:33');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
