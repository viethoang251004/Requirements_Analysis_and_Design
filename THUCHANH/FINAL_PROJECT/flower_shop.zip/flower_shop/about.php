<style>
    p {
        font-size: 20px;
        font-weight: 400;
        margin-top: 20px;
    }
</style>
<section class="py-5">
    <div class="container about">
        <div class="card rounded-0">
            <div class="card-body">
                <?php include "about.html" ?>
            </div>
        </div>
    </div>
</section>